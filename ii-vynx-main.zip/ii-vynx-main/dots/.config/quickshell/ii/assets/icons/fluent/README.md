The "start-here", "search" and "task view" icons are from here, with modifications

[Windows 11 by Joshua Oghenekaro Okwe - Figma](https://www.figma.com/community/file/1123040825921884189/windows-11)

License: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/deed.en)
